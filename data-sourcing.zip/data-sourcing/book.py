import requests

isbn = input("ISBN ? ")
print(isbn)

url = f"https://openlibrary.org/api/books"
key = f'ISBN:{isbn}'

params= {'bibkeys': key,
         'format':'json',
         'jscmd':'data'}

response = requests.get(url,
                        params=params,
                        )\
                    .json()

print(response[key]['title'])
